package com.javatpoint.model;

public class EmployeeBean {
	private String empId;
	private String empName;
	
	public EmployeeBean(String empId,String empName){
		this.empId = empId;
		this.empName = empName;
	}
	public EmployeeBean() {
		// TODO Auto-generated constructor stub
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	

}
