package com.javatpoint;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.javatpoint.model.EmployeeBean;

@Controller
@RequestMapping("/kony")
public class HelloController {
	
	@RequestMapping("/")
	public String display()
	{
		System.out.println("inside display");
		return "index";
	}
	
	@RequestMapping("/displayEmpForm")
	public String displayEmp(Model model)
	{
		System.out.println("inside displayEmp");
	    model.addAttribute("empBean", new EmployeeBean());
		return "employee";
	}
	
	@RequestMapping("/submitEmpForm")
	public ModelAndView submitEmp(@ModelAttribute EmployeeBean empBean)
	{
		ModelAndView modelAndView = new ModelAndView("employee","empBean",new EmployeeBean());
		System.out.println(empBean.getEmpId());
		System.out.println(empBean.getEmpName());
		return modelAndView;
	}
}
